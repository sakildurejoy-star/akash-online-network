AKASH ONLINE NETWORK website
=============================

Updated business details:
- Phone / WhatsApp: 01834259876
- Service area: Rangpur, Bangladesh
- Services: Internet connection, router sales/setup, network setup, technical support

Files:
- index.html: responsive Bengali website

Publish free with GitHub Pages:
1. Extract this ZIP on your phone.
2. Sign in at https://github.com
3. Create a new PUBLIC repository named `akash-online-network`.
4. Upload `index.html` to the repository root.
5. Open repository Settings -> Pages.
6. Under Build and deployment, select Deploy from a branch; choose `main` and `/ (root)`, then Save.
7. Wait for the Pages URL shown in Settings -> Pages.

Connect your own .com domain:
1. Buy/register an available .com domain from a reputable domain registrar. Check renewal price.
2. In repository Settings -> Pages -> Custom domain, enter your domain and Save.
3. Follow the exact DNS records GitHub Pages shows for your domain/registrar.
4. Wait for DNS and HTTPS to finish provisioning; enable Enforce HTTPS when available.

Important:
- Package prices and internet speeds remain placeholders. Add your real plans before publishing.
- The WhatsApp form is configured for the provided number (Bangladesh country code 880).
- The site does not store form submissions; it opens WhatsApp with a prefilled message.
